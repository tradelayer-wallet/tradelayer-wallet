import { Injectable } from "@angular/core";
import { ToastrService } from "ngx-toastr";
import { RpcService } from "./rpc.service";
import { obEventPrefix, SocketService } from "./socket.service";
import { TxsService } from "./txs.service";
import { LoadingService } from "./loading.service";
import { SwapCacheService } from "./swap-cache.service";
import { BalanceService } from "./balance.service";
import { StreamlinedSwapper, IStreamlinedTradeInfo } from 'src/app/utils/swapper/streamlined-swapper';
import { ISpotTradeProps, IFuturesTradeProps, ETradeType } from 'src/app/utils/swapper/common';
import { ISpotOrder } from "./spot-services/spot-orderbook.service";
import { IFuturesOrder } from "./futures-services/futures-orderbook.service";
import { ESounds, SoundsService } from "./sound.service";

interface IChannelSwapData {
    tradeInfo: {
        buyer: any;
        seller: any;
        props: ISpotTradeProps | IFuturesTradeProps;
        type: string;
    };
    unfilled: ISpotOrder | IFuturesOrder;
    isBuyer: boolean;
}

/**
 * SwapService - Streamlined 2-3 Round Trip Flow
 * 
 * FLOW SUMMARY:
 * 
 * Standard case (taker initiates):
 *   STEP 1: Taker prepares multisig + funding + PSBT, signs PSBT, sends to maker
 *   STEP 2: Maker validates, adds funding + signs, finalizes, broadcasts
 *   → 2 round trips total
 * 
 * Maker initiates case:
 *   STEP 1: Maker prepares multisig + funding + PSBT (unsigned), sends to taker
 *   STEP 2: Taker validates, adds funding + signs, sends back
 *   STEP 3: Maker signs, finalizes, broadcasts
 *   → 3 round trips total
 * 
 * RPC CALL SUMMARY:
 *   - Multisig creation: CACHED (0 RPCs after first trade with counterparty)
 *   - WIF lookup: CACHED (0 RPCs - prefetched on wallet load)
 *   - Block height: CACHED (0 RPCs - polled in background)
 *   - Funding tx: CACHED if available, else ~3 RPCs (build, sign, send)
 *   - RBF check: 1 RPC (required for security)
 *   - PSBT sign: 0 RPCs (done client-side with cached WIF)
 *   - Broadcast: 1 RPC
 * 
 * TOTAL: ~4-6 RPCs per trade (down from ~20)
 * 
 * CHANNEL BALANCE OPTIMIZATION:
 *   If both parties have existing channel balance, funding txs are skipped entirely
 *   → ~2-3 RPCs per trade
 */
@Injectable({
    providedIn: 'root',
})
export class SwapService {
    private activeSwaps = new Map<string, StreamlinedSwapper>();

    constructor(
        private socketService: SocketService,
        private rpcService: RpcService,
        private txsService: TxsService,
        private toastrService: ToastrService,
        private loadingService: LoadingService,
        private soundsService: SoundsService,
        private cacheService: SwapCacheService,
        private balanceService: BalanceService,
    ) {}

    private get socket() {
        return this.socketService.socket;
    }

    /**
     * Initialize swap service
     */
    async onInit() {
        // Initialize cache layer (prefetches WIFs, starts block height polling)
        await this.cacheService.onInit();
        console.log('[SwapService] Cache initialized:', this.cacheService.getStats());

        // Pre-compute margins for active contracts (if any)
        await this.precomputeMargins();

        // Listen for incoming trade requests
        this.socket.on(`${obEventPrefix}::new-channel`, async (swapConfig: IChannelSwapData) => {
            console.log('[SwapService] New channel swap:', JSON.stringify(swapConfig));

            this.loadingService.tradesLoading = false;
            const res = await this.executeSwap(swapConfig);

            if (!res || res.error || !res.data?.txid) {
                this.toastrService.error(res?.error || 'Unknown Error', 'Trade Error');
            } else {
                this.soundsService.playSound(ESounds.TRADE_COMPLETED);
                this.toastrService.success('Trade Completed', res.data.txid, { timeOut: 3000 });
            }
        });
    }

    /**
     * Execute a swap using the streamlined flow
     */
    private async executeSwap(swapConfig: IChannelSwapData): Promise<{ data?: { txid: string }; error?: string }> {
        const { tradeInfo, isBuyer } = swapConfig;
        const { buyer, seller, props, type } = tradeInfo;

        // Generate unique trade ID
        const tradeUUID = this.generateTradeUUID(buyer, seller);

        // Check for duplicate
        if (this.activeSwaps.has(tradeUUID)) {
            console.warn('[SwapService] Duplicate swap detected:', tradeUUID);
            return { error: 'Duplicate swap attempt' };
        }

        // Determine maker/taker
        const buyerIsMaker = this.determineMaker(swapConfig);

        // Build trade info
        const streamlinedTradeInfo: IStreamlinedTradeInfo = {
            type: type as ETradeType,
            props,
            buyer,
            seller,
            buyerIsMaker
        };

        // Create swapper instance
        const myInfo = isBuyer ? buyer : seller;
        const cpInfo = isBuyer ? seller : buyer;

        const swapper = new StreamlinedSwapper(
            streamlinedTradeInfo,
            myInfo,
            cpInfo,
            isBuyer,
            this.rpcService.rpc.bind(this.rpcService),
            this.socket,
            this.txsService,
            this.toastrService,
            this.cacheService,
            this.balanceService,
            tradeUUID
        );

        // Track active swap
        this.activeSwaps.set(tradeUUID, swapper);

        // Subscribe to events for UI feedback
        swapper.eventSubs$.subscribe(({ event, data }) => {
            this.toastrService.info(event, 'Trade Progress', { timeOut: 2000 });
        });

        try {
            // Execute the swap
            const result = await swapper.onReady();
            return result;
        } finally {
            // Cleanup
            this.activeSwaps.delete(tradeUUID);
            swapper.cleanup();
        }
    }

    /**
     * Generate unique trade ID
     */
    private generateTradeUUID(buyer: any, seller: any): string {
        return `${buyer?.uuid || 'b'}-${seller?.uuid || 's'}-${Date.now()}`;
    }

    /**
     * Determine who is the maker (posted the order) vs taker (filled it)
     */
    private determineMaker(swapConfig: IChannelSwapData): boolean {
        // The unfilled order's owner is the maker
        const unfilled = swapConfig.unfilled;
        if (!unfilled) return false;

        // Check if buyer posted the original order
        return unfilled.address === swapConfig.tradeInfo.buyer?.keypair?.address;
    }

    /**
     * Pre-compute and cache margin requirements for active contracts
     */
    private async precomputeMargins(): Promise<void> {
        // This would query active contracts and pre-compute margins
        // For now, margins are computed on-demand and cached
        console.log('[SwapService] Margin pre-computation placeholder');
    }

    /**
     * Cancel an active swap
     */
    cancelSwap(tradeUUID: string): void {
        const swapper = this.activeSwaps.get(tradeUUID);
        if (swapper) {
            swapper.cleanup();
            this.activeSwaps.delete(tradeUUID);
        }
    }

    /**
     * Get cache statistics
     */
    getCacheStats() {
        return this.cacheService.getStats();
    }

    /**
     * Get active swap count
     */
    getActiveSwapCount(): number {
        return this.activeSwaps.size;
    }
}
