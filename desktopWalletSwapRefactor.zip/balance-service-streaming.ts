import { Injectable } from "@angular/core";
import { BehaviorSubject, Subject } from "rxjs";
import { RpcService } from "./rpc.service";
import { ToastrService } from "ngx-toastr";
import { AuthService } from "./auth.service";
import { IUTXO, TxsService } from "./txs.service";
import { ApiService } from "./api.service";
import { SocketService } from "./socket.service";

const minBlocksForBalanceConf: number = 1;
const emptyBalanceObj = {
    coinBalance: {
        confirmed: 0,
        unconfirmed: 0,
        utxos: [],
    },
    tokensBalance: [],
};

/**
 * Token balance structure including channel balance
 */
interface ITokenBalance {
    name: string;
    propertyid: number;
    amount: number;
    available: number;
    reserved: number;
    margin: number;
    vesting: number;
    channel: number;  // Balance already in channels - can be used directly
}

/**
 * Pre-built funding transaction ready for signing
 */
interface IPrefundedTx {
    propertyId: number;
    amount: number;
    toAddress: string;  // Multisig address
    rawtx: string;
    utxosUsed: IUTXO[];
    createdAt: number;
    expiresAt: number;  // Invalidate after N blocks
}

/**
 * Channel balance entry - tokens already committed to a multisig
 */
interface IChannelBalance {
    multisigAddress: string;
    propertyId: number;
    amount: number;
    myShare: number;
    cpShare: number;
    lastUpdated: number;
}

@Injectable({
    providedIn: 'root',
})
export class BalanceService {
    private _allBalancesObj: {
        [key: string]: {
            coinBalance: {
                confirmed: number;
                unconfirmed: number;
                utxos: IUTXO[];
            };
            tokensBalance: ITokenBalance[];
        }
    } = {};

    // === NEW: Streaming UTXO Management ===
    
    // Local UTXO set - updated via streaming, not polling
    private utxoSet: Map<string, IUTXO> = new Map(); // key: txid:vout
    
    // UTXOs currently locked for pending transactions
    private lockedUtxos: Set<string> = new Set();
    
    // Pre-built funding transactions ready to sign
    private prefundedTxCache: Map<string, IPrefundedTx> = new Map(); // key: propertyId:amount:toAddress
    
    // Channel balances - tokens already in multisigs
    private channelBalances: Map<string, IChannelBalance> = new Map(); // key: multisigAddress:propertyId
    
    // Observables for reactive updates
    public utxoUpdates$ = new Subject<{ type: 'add' | 'remove' | 'confirm', utxo: IUTXO }>();
    public balanceUpdates$ = new BehaviorSubject<void>(undefined);

    // Block height tracking
    private currentBlockHeight: number = 0;

    constructor(
        private rpcService: RpcService,
        private authService: AuthService,
        private toastrService: ToastrService,
        private apiService: ApiService,
        private txsService: TxsService,
        private socketService: SocketService
    ) { }

    get tlApi() {
        return this.apiService.newTlApi;
    }

    get sumAvailableCoins() {
        return Object.values(this._allBalancesObj)
            .reduce((a, b) => a + b.coinBalance.confirmed, 0);
    }

    get allBalances() {
        return this._allBalancesObj;
    }

    // === PUBLIC API ===

    getCoinBalancesByAddress(_address: string) {
        const address = _address;
        if (!address) return emptyBalanceObj.coinBalance;
        return this._allBalancesObj?.[address]?.coinBalance || emptyBalanceObj.coinBalance;
    }

    getTokensBalancesByAddress(_address: string) {
        const address = _address;
        if (!address) return [];
        return this._allBalancesObj?.[address]?.tokensBalance || [];
    }

    /**
     * Get available (unlocked) UTXOs for an address
     */
    getAvailableUtxos(address: string): IUTXO[] {
        const allUtxos = this._allBalancesObj[address]?.coinBalance.utxos || [];
        return allUtxos.filter(utxo => {
            const key = `${utxo.txid}:${utxo.vout}`;
            return !this.lockedUtxos.has(key);
        });
    }

    /**
     * Get token balance including channel balance
     */
    getTokenBalance(address: string, propertyId: number): { available: number; channel: number; total: number } {
        const tokens = this.getTokensBalancesByAddress(address);
        const token = tokens.find(t => t.propertyid === propertyId);
        if (!token) return { available: 0, channel: 0, total: 0 };
        return {
            available: token.available,
            channel: token.channel,
            total: token.available + token.channel
        };
    }

    /**
     * Check if we have sufficient balance (wallet OR channel) for a trade
     */
    hasSufficientBalance(address: string, propertyId: number, amount: number, multisigAddress?: string): {
        sufficient: boolean;
        useChannel: boolean;
        channelBalance?: number;
        walletBalance?: number;
    } {
        const balance = this.getTokenBalance(address, propertyId);
        
        // Check channel balance first (no funding tx needed)
        if (multisigAddress) {
            const channelBal = this.getChannelBalance(multisigAddress, propertyId);
            if (channelBal && channelBal.myShare >= amount) {
                return { sufficient: true, useChannel: true, channelBalance: channelBal.myShare };
            }
        }
        
        // Fall back to wallet balance
        if (balance.available >= amount) {
            return { sufficient: true, useChannel: false, walletBalance: balance.available };
        }
        
        return { sufficient: false, useChannel: false, walletBalance: balance.available, channelBalance: 0 };
    }

    // === UTXO LOCKING ===

    /**
     * Lock UTXOs for a pending transaction
     */
    lockUtxos(utxos: IUTXO[]): void {
        for (const utxo of utxos) {
            const key = `${utxo.txid}:${utxo.vout}`;
            this.lockedUtxos.add(key);
        }
    }

    /**
     * Unlock UTXOs (on trade failure or cancellation)
     */
    unlockUtxos(utxos: IUTXO[]): void {
        for (const utxo of utxos) {
            const key = `${utxo.txid}:${utxo.vout}`;
            this.lockedUtxos.delete(key);
        }
    }

    /**
     * Mark UTXOs as spent (on trade success)
     */
    markUtxosSpent(utxos: IUTXO[]): void {
        for (const utxo of utxos) {
            const key = `${utxo.txid}:${utxo.vout}`;
            this.lockedUtxos.delete(key);
            this.utxoSet.delete(key);
            this.utxoUpdates$.next({ type: 'remove', utxo });
        }
    }

    // === CHANNEL BALANCE MANAGEMENT ===

    /**
     * Get channel balance for a specific multisig
     */
    getChannelBalance(multisigAddress: string, propertyId: number): IChannelBalance | undefined {
        const key = `${multisigAddress}:${propertyId}`;
        return this.channelBalances.get(key);
    }

    /**
     * Update channel balance after a trade or commit
     */
    updateChannelBalance(
        multisigAddress: string,
        propertyId: number,
        myShare: number,
        cpShare: number
    ): void {
        const key = `${multisigAddress}:${propertyId}`;
        this.channelBalances.set(key, {
            multisigAddress,
            propertyId,
            amount: myShare + cpShare,
            myShare,
            cpShare,
            lastUpdated: Date.now()
        });
    }

    /**
     * Clear channel balance (after channel close)
     */
    clearChannelBalance(multisigAddress: string, propertyId?: number): void {
        if (propertyId !== undefined) {
            const key = `${multisigAddress}:${propertyId}`;
            this.channelBalances.delete(key);
        } else {
            // Clear all balances for this multisig
            for (const key of this.channelBalances.keys()) {
                if (key.startsWith(multisigAddress)) {
                    this.channelBalances.delete(key);
                }
            }
        }
    }

    // === PRE-FUNDED TRANSACTION CACHE ===

    /**
     * Get or build a pre-funded commit transaction
     * This is the key optimization - we build funding txs BEFORE trades start
     */
    async getOrBuildFundingTx(
        fromAddress: string,
        toAddress: string,  // Multisig address
        propertyId: number,
        amount: number,
        payload: string
    ): Promise<{ data?: { rawtx: string; utxosUsed: IUTXO[] }; error?: string; cached: boolean }> {
        
        const cacheKey = `${propertyId}:${amount}:${toAddress}`;
        const cached = this.prefundedTxCache.get(cacheKey);
        
        // Check if cached tx is still valid
        if (cached && cached.expiresAt > this.currentBlockHeight) {
            // Verify UTXOs are still available
            const utxosStillAvailable = cached.utxosUsed.every(utxo => {
                const key = `${utxo.txid}:${utxo.vout}`;
                return this.utxoSet.has(key) && !this.lockedUtxos.has(key);
            });
            
            if (utxosStillAvailable) {
                // Lock UTXOs and return cached tx
                this.lockUtxos(cached.utxosUsed);
                return { 
                    data: { rawtx: cached.rawtx, utxosUsed: cached.utxosUsed }, 
                    cached: true 
                };
            } else {
                // Invalidate stale cache entry
                this.prefundedTxCache.delete(cacheKey);
            }
        }
        
        // Build new funding tx
        const buildRes = await this.txsService.buildTx({
            fromKeyPair: { address: fromAddress },
            toKeyPair: { address: toAddress },
            payload
        });
        
        if (buildRes.error || !buildRes.data) {
            return { error: buildRes.error || 'Failed to build funding tx', cached: false };
        }
        
        // Extract UTXOs used (we need this info from buildTx)
        const utxosUsed = buildRes.data.inputsUsed || [];
        
        // Cache for future use (valid for ~10 blocks)
        this.prefundedTxCache.set(cacheKey, {
            propertyId,
            amount,
            toAddress,
            rawtx: buildRes.data.rawtx,
            utxosUsed,
            createdAt: Date.now(),
            expiresAt: this.currentBlockHeight + 10
        });
        
        // Lock UTXOs
        this.lockUtxos(utxosUsed);
        
        return { data: { rawtx: buildRes.data.rawtx, utxosUsed }, cached: false };
    }

    /**
     * Invalidate all pre-funded transactions (on new block or UTXO change)
     */
    invalidatePrefundedTxs(): void {
        // Only invalidate expired entries
        for (const [key, tx] of this.prefundedTxCache) {
            if (tx.expiresAt <= this.currentBlockHeight) {
                this.unlockUtxos(tx.utxosUsed);
                this.prefundedTxCache.delete(key);
            }
        }
    }

    // === INITIALIZATION & STREAMING ===

    onInit() {
        this.authService.updateAddressesSubs$
            .subscribe(kp => {
                if (!kp.length) this.restartBalance();
                this.updateBalances();
            });

        // Subscribe to block updates
        this.rpcService.blockSubs$.subscribe((blockHeight) => {
            this.currentBlockHeight = blockHeight || this.currentBlockHeight;
            this.invalidatePrefundedTxs();
            this.updateBalances(false);
        });

        // Set up UTXO streaming if available
        this.setupUtxoStreaming();

        // Fallback polling (reduced frequency since we have streaming)
        setInterval(() => this.updateBalances(false), 30000);
    }

    /**
     * Set up WebSocket streaming for UTXO updates
     */
    private setupUtxoStreaming(): void {
        const socket = this.socketService.socket;
        
        // New UTXO received (incoming tx or change)
        socket.on('utxo:new', (utxo: IUTXO) => {
            const key = `${utxo.txid}:${utxo.vout}`;
            this.utxoSet.set(key, utxo);
            this.utxoUpdates$.next({ type: 'add', utxo });
            this.rebuildBalanceFromUtxoSet();
        });
        
        // UTXO spent
        socket.on('utxo:spent', (outpoint: { txid: string; vout: number }) => {
            const key = `${outpoint.txid}:${outpoint.vout}`;
            const utxo = this.utxoSet.get(key);
            if (utxo) {
                this.utxoSet.delete(key);
                this.lockedUtxos.delete(key);
                this.utxoUpdates$.next({ type: 'remove', utxo });
                this.rebuildBalanceFromUtxoSet();
            }
        });
        
        // UTXO confirmed
        socket.on('utxo:confirmed', (outpoint: { txid: string; vout: number; confirmations: number }) => {
            const key = `${outpoint.txid}:${outpoint.vout}`;
            const utxo = this.utxoSet.get(key);
            if (utxo) {
                utxo.confirmations = outpoint.confirmations;
                this.utxoUpdates$.next({ type: 'confirm', utxo });
                this.rebuildBalanceFromUtxoSet();
            }
        });

        // Token balance update
        socket.on('balance:tokens', (data: { address: string; balances: ITokenBalance[] }) => {
            if (this._allBalancesObj[data.address]) {
                this._allBalancesObj[data.address].tokensBalance = data.balances;
                this.balanceUpdates$.next();
            }
        });

        // Channel balance update
        socket.on('channel:balance', (data: IChannelBalance) => {
            this.updateChannelBalance(
                data.multisigAddress,
                data.propertyId,
                data.myShare,
                data.cpShare
            );
        });
    }

    /**
     * Rebuild coin balances from local UTXO set
     */
    private rebuildBalanceFromUtxoSet(): void {
        const addresses = this.authService.walletAddresses || [];
        
        for (const address of addresses) {
            const addressUtxos = Array.from(this.utxoSet.values())
                .filter(utxo => utxo.address === address);
            
            const confirmed = addressUtxos
                .filter(utxo => utxo.confirmations >= minBlocksForBalanceConf)
                .reduce((sum, utxo) => sum + utxo.amount, 0);
            
            const unconfirmed = addressUtxos
                .filter(utxo => utxo.confirmations < minBlocksForBalanceConf)
                .reduce((sum, utxo) => sum + utxo.amount, 0);
            
            if (!this._allBalancesObj[address]) {
                this._allBalancesObj[address] = { ...emptyBalanceObj };
            }
            
            this._allBalancesObj[address].coinBalance = {
                confirmed: parseFloat(confirmed.toFixed(6)),
                unconfirmed: parseFloat(unconfirmed.toFixed(6)),
                utxos: addressUtxos
            };
        }
        
        this.balanceUpdates$.next();
    }

    // === EXISTING METHODS (kept for compatibility) ===

    async updateBalances(notify: boolean = true) {
        try {
            const addressesArray = this.authService.walletAddresses;
            for (let i = 0; i < addressesArray?.length; i++) {
                const address = addressesArray[i];
                await this.updateCoinBalanceForAddressFromUnspents(address);
                await this.updateTokensBalanceForAddress(address);
            }
            this.balanceUpdates$.next();
        } catch (err: any) {
            this.toastrService.warning(err.message || `Error with updating balances`, 'Balance Error');
        }
    }

    private async updateCoinBalanceForAddressFromUnspents(address: string) {
        const coinBalanceObjRes = await this.getCoinBalanceObjForAddress(address);
        if (coinBalanceObjRes.error || !coinBalanceObjRes.data) {
            throw new Error(coinBalanceObjRes.error || `Error with updating balances: ${address}`);
        }
        const { confirmed, unconfirmed, utxos } = coinBalanceObjRes.data;
        
        // Update local UTXO set
        for (const utxo of utxos) {
            const key = `${utxo.txid}:${utxo.vout}`;
            (utxo as any).address = address; // Tag with address
            this.utxoSet.set(key, utxo);
        }
        
        const coinObj = { confirmed, unconfirmed, utxos };
        if (!this._allBalancesObj[address]) this._allBalancesObj[address] = { ...emptyBalanceObj };
        this._allBalancesObj = {
            ...this._allBalancesObj,
            [address]: {
                ...this._allBalancesObj[address],
                coinBalance: coinObj,
            },
        };
    }

    private async updateTokensBalanceForAddress(address: string) {
        const tokensBalanceArrRes = await this.getTokensBalanceArrForAddress(address);
        if (tokensBalanceArrRes.error || !tokensBalanceArrRes.data) {
            throw new Error(tokensBalanceArrRes.error || `Error with updating balances`);
        }
        if (!this._allBalancesObj[address]) this._allBalancesObj[address] = { ...emptyBalanceObj };
        this._allBalancesObj[address].tokensBalance = tokensBalanceArrRes.data;
    }

    private async getCoinBalanceObjForAddress(address: string) {
        if (!address) return { error: 'No address provided for updating the balance' };
        const luRes = await this.rpcService.rpc('listunspent', [0, 999999999, [address]]);
        if (luRes.error || !luRes.data) return { error: luRes.error || 'Undefined Error' };

        const _confirmed = (luRes.data as IUTXO[])
            .filter(utxo => utxo.confirmations >= minBlocksForBalanceConf)
            .reduce((a, b) => a + b.amount, 0);
        const _unconfirmed = (luRes.data as IUTXO[])
            .filter(utxo => utxo.confirmations < minBlocksForBalanceConf)
            .reduce((a, b) => a + b.amount, 0);
        const confirmed = parseFloat(_confirmed.toFixed(6));
        const unconfirmed = parseFloat(_unconfirmed.toFixed(6));
        return { data: { confirmed, unconfirmed, utxos: luRes.data } };
    }

    private async getTokensBalanceArrForAddress(address: string) {
        if (!address) return { error: 'No address provided for updating the balance' };
        const balanceRes = await this.tlApi.rpc('getAllBalancesForAddress', [address]).toPromise();
        if (!balanceRes.data || balanceRes.error) return { data: [] };
        const data = (balanceRes.data as any[])
            .map((token) => ({
                ...token,
                name: token.ticker || '-',
                propertyid: parseInt(token.propertyId || '0', 10),
                amount: token?.amount || 0,
                available: token?.available || 0,
                reserved: token?.reserved || 0,
                margin: token?.margin || 0,
                vesting: token?.vesting || 0,
                channel: token?.channel || 0
            }));
        return { data };
    }

    async getTokenNameById(id: number) {
        const existingTokenName = Object.values(this._allBalancesObj)
            .reduce((acc: { name: string, propertyid: number }[], val) => acc.concat(val.tokensBalance), [])
            .find(e => e.propertyid === id);
        if (existingTokenName?.name) return existingTokenName.name;
        const gpRes = await this.tlApi.rpc('tl_getproperty', [id]).toPromise();
        if (gpRes.error || !gpRes.data?.name) return `ID_${id}`;
        return gpRes.data.name;
    }

    private restartBalance() {
        this._allBalancesObj = {};
        this.utxoSet.clear();
        this.lockedUtxos.clear();
        this.prefundedTxCache.clear();
        this.channelBalances.clear();
    }
}
