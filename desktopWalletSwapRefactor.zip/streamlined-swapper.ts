import { Socket as SocketClient } from 'socket.io-client';
import { IUTXO, TxsService } from "src/app/@core/services/txs.service";
import { IMSChannelData, SwapEvent, IBuyerSellerInfo, TClient, IFuturesTradeProps, ISpotTradeProps, ETradeType } from "./common";
import { ENCODER } from '../payloads/encoder';
import { ToastrService } from "ngx-toastr";
import { SwapCacheService } from "src/app/@core/services/swap-cache.service";
import { BalanceService } from "src/app/@core/services/balance.service";
import { Subject } from 'rxjs';

/**
 * STREAMLINED SWAP FLOW - 2-3 Round Trips
 * 
 * OLD FLOW (6 steps, ~20 RPCs):
 *   Seller: init multisig → Buyer: verify multisig → Seller: commit → 
 *   Buyer: commit + PSBT → Seller: sign PSBT → Buyer: finalize + broadcast
 * 
 * NEW FLOW (2-3 steps, ~4-6 RPCs):
 * 
 * STEP 1 - INITIATOR PREPARES EVERYTHING:
 *   - Get/create multisig (cached)
 *   - Check balance: channel balance OR pre-built funding tx
 *   - Build complete PSBT with their input
 *   - If TAKER: sign PSBT
 *   - Send: { multisig, psbt, fundingTx?, isSigned }
 * 
 * STEP 2 - RESPONDER VALIDATES & CO-SIGNS:
 *   - Verify multisig (cached)
 *   - Check their balance: channel OR build funding
 *   - RBF check on initiator's funding (if any)
 *   - Add their input to PSBT
 *   - Sign PSBT
 *   - If initiator was taker: finalize & broadcast
 *   - If initiator was maker: send back for final signature
 * 
 * STEP 3 (only if initiator is MAKER):
 *   - Initiator signs completed PSBT
 *   - Finalize & broadcast
 * 
 * KEY OPTIMIZATIONS:
 *   - Multisig cached by pubkey pair
 *   - WIFs pre-fetched on wallet load
 *   - Block height polled in background
 *   - UTXOs tracked via streaming (desktop) or polling (web)
 *   - Channel balances eliminate funding txs entirely
 *   - Pre-built funding txs cached until block change
 */

// === TYPES ===

interface ISwapPrepData {
    multisig: IMSChannelData;
    psbtHex: string;
    fundingTxHex?: string;      // Signed funding tx (if using wallet balance)
    fundingTxId?: string;       // Txid of funding (for RBF check)
    commitUtxo?: IUTXO;         // UTXO created by funding tx
    useChannelBalance: boolean; // True if using existing channel balance
    isSigned: boolean;          // True if initiator already signed (taker)
    isMaker: boolean;           // True if initiator is maker
    tradeUUID: string;
}

interface ISwapResponseData {
    psbtHex: string;            // Fully or partially signed PSBT
    fundingTxHex?: string;      // Responder's signed funding tx
    fundingTxId?: string;
    commitUtxo?: IUTXO;
    needsFinalSignature: boolean; // True if initiator needs to sign again
    finalTxHex?: string;        // If complete, the final tx hex
    finalTxId?: string;         // If broadcast, the txid
}

export interface IStreamlinedTradeInfo {
    type: ETradeType;
    props: ISpotTradeProps | IFuturesTradeProps;
    buyer: IBuyerSellerInfo;
    seller: IBuyerSellerInfo;
    buyerIsMaker: boolean;
}

// === STREAMLINED SWAPPER ===

export class StreamlinedSwapper {
    public eventSubs$ = new Subject<{ event: string; data?: any }>();
    
    private multySigChannelData: IMSChannelData | null = null;
    private tradeStartTime: number;
    private readyResolve: ((value: any) => void) | null = null;
    private readyReject: ((reason?: any) => void) | null = null;

    constructor(
        private tradeInfo: IStreamlinedTradeInfo,
        private myInfo: IBuyerSellerInfo,
        private cpInfo: IBuyerSellerInfo,
        private isBuyer: boolean,
        private client: TClient,
        private socket: SocketClient,
        private txsService: TxsService,
        private toastrService: ToastrService,
        private cacheService: SwapCacheService,
        private balanceService: BalanceService,
        private tradeUUID: string
    ) {
        this.tradeStartTime = Date.now();
        this.setupEventHandlers();
    }

    private logTime(stage: string) {
        console.log(`[Swap:${this.tradeUUID.slice(0,8)}] ${stage}: ${Date.now() - this.tradeStartTime}ms`);
    }

    private get isMaker(): boolean {
        return this.isBuyer ? this.tradeInfo.buyerIsMaker : !this.tradeInfo.buyerIsMaker;
    }

    private get isInitiator(): boolean {
        // Seller always initiates (they have what buyer wants)
        return !this.isBuyer;
    }

    // === PUBLIC API ===

    /**
     * Start the swap - returns promise that resolves on completion
     */
    onReady(): Promise<{ data?: { txid: string }; error?: string }> {
        return new Promise((resolve, reject) => {
            this.readyResolve = resolve;
            this.readyReject = reject;
            
            if (this.isInitiator) {
                this.initiateSwap();
            }
            // Non-initiator waits for STEP1 event
        });
    }

    /**
     * Clean up event listeners
     */
    cleanup(): void {
        const eventName = `${this.cpInfo.socketId}::streamlined-swap`;
        this.socket.off(eventName);
    }

    // === EVENT HANDLING ===

    private setupEventHandlers(): void {
        const eventName = `${this.cpInfo.socketId}::streamlined-swap`;
        
        this.socket.on(eventName, async (event: SwapEvent) => {
            // Ignore events for other trades
            if (event.data?.tradeUUID && event.data.tradeUUID !== this.tradeUUID) {
                return;
            }

            this.eventSubs$.next({ event: event.eventName, data: event.data });

            try {
                switch (event.eventName) {
                    case 'STEP1':
                        await this.handleStep1(event.data as ISwapPrepData);
                        break;
                    case 'STEP2':
                        await this.handleStep2(event.data as ISwapResponseData);
                        break;
                    case 'STEP3_COMPLETE':
                        this.handleComplete(event.data as { txid: string });
                        break;
                    case 'TERMINATE':
                        this.handleTerminate(event.data?.reason || 'Unknown error');
                        break;
                }
            } catch (err: any) {
                this.terminate(`Event handler error: ${err.message}`);
            }
        });
    }

    private emit(eventName: string, data: any): void {
        const event = new SwapEvent(eventName, this.myInfo.socketId, {
            ...data,
            tradeUUID: this.tradeUUID
        });
        this.socket.emit(`${this.myInfo.socketId}::streamlined-swap`, event);
    }

    private terminate(reason: string): void {
        this.logTime(`TERMINATED: ${reason}`);
        this.emit('TERMINATE', { reason });
        this.cleanup();
        this.readyResolve?.({ error: reason });
    }

    private handleTerminate(reason: string): void {
        this.logTime(`TERMINATED BY PEER: ${reason}`);
        this.cleanup();
        
        // Unlock any UTXOs we locked
        // (handled by balance service cleanup)
        
        this.readyResolve?.({ error: reason });
    }

    private handleComplete(data: { txid: string }): void {
        this.logTime(`COMPLETE: ${data.txid}`);
        this.cleanup();
        this.toastrService.success('Trade completed!', data.txid);
        this.readyResolve?.({ data: { txid: data.txid } });
    }

    // === STEP 1: INITIATOR PREPARES EVERYTHING ===

    private async initiateSwap(): Promise<void> {
        this.logTime('STEP1: Initiator preparing');

        try {
            // 1. Get or create multisig (CACHED)
            const pubKeys = this.getPubkeyOrder();
            const msResult = await this.cacheService.getOrCreateMultisig(pubKeys);
            if (msResult.error || !msResult.data) {
                throw new Error(`Multisig error: ${msResult.error}`);
            }
            this.multySigChannelData = msResult.data;

            // 2. Check balance - channel or wallet?
            const { propertyId, amount } = this.getMyCommitRequirements();
            const balanceCheck = this.balanceService.hasSufficientBalance(
                this.myInfo.keypair.address,
                propertyId,
                amount,
                this.multySigChannelData.address
            );

            if (!balanceCheck.sufficient) {
                throw new Error(`Insufficient balance: need ${amount} of property ${propertyId}`);
            }

            let fundingTxHex: string | undefined;
            let fundingTxId: string | undefined;
            let commitUtxo: IUTXO | undefined;

            // 3. If not using channel balance, build funding tx
            if (!balanceCheck.useChannel) {
                const fundingResult = await this.buildAndSignFundingTx(propertyId, amount);
                if (fundingResult.error) {
                    throw new Error(fundingResult.error);
                }
                fundingTxHex = fundingResult.signedHex;
                fundingTxId = fundingResult.txid;
                commitUtxo = fundingResult.commitUtxo;

                // Send funding tx to mempool
                const sendRes = await this.txsService.sendTx(fundingTxHex!);
                if (sendRes.error) {
                    throw new Error(`Send funding tx: ${sendRes.error}`);
                }
                fundingTxId = sendRes.data;
            }

            // 4. Build the trade PSBT
            const psbtResult = await this.buildTradePsbt(commitUtxo, balanceCheck.useChannel);
            if (psbtResult.error || !psbtResult.psbtHex) {
                throw new Error(`Build PSBT: ${psbtResult.error}`);
            }

            // 5. If we're TAKER, sign now (maker signs last)
            let psbtHex = psbtResult.psbtHex;
            let isSigned = false;

            if (!this.isMaker) {
                const signResult = await this.signPsbt(psbtHex);
                if (signResult.error) {
                    throw new Error(`Sign PSBT: ${signResult.error}`);
                }
                psbtHex = signResult.psbtHex!;
                isSigned = true;
            }

            // 6. Send to counterparty
            const prepData: ISwapPrepData = {
                multisig: this.multySigChannelData,
                psbtHex,
                fundingTxHex,
                fundingTxId,
                commitUtxo,
                useChannelBalance: balanceCheck.useChannel,
                isSigned,
                isMaker: this.isMaker,
                tradeUUID: this.tradeUUID
            };

            this.emit('STEP1', prepData);
            this.logTime('STEP1: Sent to counterparty');

        } catch (err: any) {
            this.terminate(`Step 1: ${err.message}`);
        }
    }

    // === STEP 2: RESPONDER VALIDATES & CO-SIGNS ===

    private async handleStep1(data: ISwapPrepData): Promise<void> {
        this.logTime('STEP2: Responder processing');

        try {
            // 1. Verify multisig (CACHED)
            const pubKeys = this.getPubkeyOrder();
            const verifyResult = await this.cacheService.verifyMultisig(pubKeys, data.multisig.redeemScript);
            if (!verifyResult.valid) {
                throw new Error(`Multisig verification failed: ${verifyResult.error}`);
            }
            this.multySigChannelData = data.multisig;

            // 2. RBF check on initiator's funding tx (security requirement)
            if (data.fundingTxId && !data.useChannelBalance) {
                const rbfCheck = await this.checkRbf(data.fundingTxId);
                if (rbfCheck.isRbf) {
                    throw new Error('RBF-enabled funding tx detected - aborting');
                }
            }

            // 3. Check our balance - channel or wallet?
            const { propertyId, amount } = this.getMyCommitRequirements();
            const balanceCheck = this.balanceService.hasSufficientBalance(
                this.myInfo.keypair.address,
                propertyId,
                amount,
                this.multySigChannelData.address
            );

            if (!balanceCheck.sufficient) {
                throw new Error(`Insufficient balance: need ${amount} of property ${propertyId}`);
            }

            let myFundingTxHex: string | undefined;
            let myFundingTxId: string | undefined;
            let myCommitUtxo: IUTXO | undefined;

            // 4. If not using channel balance, build and send our funding tx
            if (!balanceCheck.useChannel) {
                const fundingResult = await this.buildAndSignFundingTx(propertyId, amount);
                if (fundingResult.error) {
                    throw new Error(fundingResult.error);
                }
                myFundingTxHex = fundingResult.signedHex;

                const sendRes = await this.txsService.sendTx(myFundingTxHex!);
                if (sendRes.error) {
                    throw new Error(`Send funding tx: ${sendRes.error}`);
                }
                myFundingTxId = sendRes.data;
                myCommitUtxo = { ...fundingResult.commitUtxo!, txid: myFundingTxId };
            }

            // 5. Add our input to the PSBT and sign
            let psbtHex = data.psbtHex;
            
            // If we need to add our commit UTXO to the PSBT
            if (myCommitUtxo) {
                const addInputResult = await this.addInputToPsbt(psbtHex, myCommitUtxo);
                if (addInputResult.error) {
                    throw new Error(`Add input: ${addInputResult.error}`);
                }
                psbtHex = addInputResult.psbtHex!;
            }

            // Sign the PSBT
            const signResult = await this.signPsbt(psbtHex);
            if (signResult.error) {
                throw new Error(`Sign PSBT: ${signResult.error}`);
            }
            psbtHex = signResult.psbtHex!;

            // 6. Determine if we can finalize or need to send back
            let responseData: ISwapResponseData;

            if (data.isSigned) {
                // Initiator already signed (they were taker) - we can finalize
                const finalizeResult = await this.finalizePsbt(psbtHex);
                if (finalizeResult.error) {
                    throw new Error(`Finalize: ${finalizeResult.error}`);
                }

                // Broadcast
                const broadcastRes = await this.txsService.sendTxWithSpecRetry(finalizeResult.finalHex!);
                if (broadcastRes.error) {
                    throw new Error(`Broadcast: ${broadcastRes.error}`);
                }

                responseData = {
                    psbtHex,
                    fundingTxHex: myFundingTxHex,
                    fundingTxId: myFundingTxId,
                    commitUtxo: myCommitUtxo,
                    needsFinalSignature: false,
                    finalTxHex: finalizeResult.finalHex,
                    finalTxId: broadcastRes.data
                };

                // Notify completion
                this.emit('STEP3_COMPLETE', { txid: broadcastRes.data });
                this.handleComplete({ txid: broadcastRes.data });

            } else {
                // Initiator is maker - needs to sign last
                responseData = {
                    psbtHex,
                    fundingTxHex: myFundingTxHex,
                    fundingTxId: myFundingTxId,
                    commitUtxo: myCommitUtxo,
                    needsFinalSignature: true
                };

                this.emit('STEP2', responseData);
            }

            this.logTime('STEP2: Complete');

        } catch (err: any) {
            this.terminate(`Step 2: ${err.message}`);
        }
    }

    // === STEP 3: MAKER FINALIZES (only if initiator was maker) ===

    private async handleStep2(data: ISwapResponseData): Promise<void> {
        this.logTime('STEP3: Maker finalizing');

        try {
            if (!data.needsFinalSignature) {
                // Shouldn't happen - responder already finalized
                return;
            }

            // RBF check on responder's funding tx
            if (data.fundingTxId) {
                const rbfCheck = await this.checkRbf(data.fundingTxId);
                if (rbfCheck.isRbf) {
                    throw new Error('RBF-enabled funding tx detected - aborting');
                }
            }

            // Sign the PSBT (we're the maker, signing last)
            const signResult = await this.signPsbt(data.psbtHex);
            if (signResult.error) {
                throw new Error(`Sign PSBT: ${signResult.error}`);
            }

            // Finalize
            const finalizeResult = await this.finalizePsbt(signResult.psbtHex!);
            if (finalizeResult.error) {
                throw new Error(`Finalize: ${finalizeResult.error}`);
            }

            // Broadcast
            const broadcastRes = await this.txsService.sendTxWithSpecRetry(finalizeResult.finalHex!);
            if (broadcastRes.error) {
                throw new Error(`Broadcast: ${broadcastRes.error}`);
            }

            // Notify counterparty
            this.emit('STEP3_COMPLETE', { txid: broadcastRes.data });
            this.handleComplete({ txid: broadcastRes.data });

            this.logTime('STEP3: Complete');

        } catch (err: any) {
            this.terminate(`Step 3: ${err.message}`);
        }
    }

    // === HELPER METHODS ===

    private getPubkeyOrder(): [string, string] {
        // Order determines column A/B - seller's pubkey first for standard trades
        const { propIdDesired, propIdForSale } = this.tradeInfo.props as ISpotTradeProps;
        
        if (this.tradeInfo.type === ETradeType.SPOT && (propIdDesired === 0 || propIdForSale === 0)) {
            // LTC trade - buyer's pubkey first
            return [this.tradeInfo.buyer.keypair.pubkey, this.tradeInfo.seller.keypair.pubkey];
        }
        
        return [this.tradeInfo.seller.keypair.pubkey, this.tradeInfo.buyer.keypair.pubkey];
    }

    private getMyCommitRequirements(): { propertyId: number; amount: number } {
        const props = this.tradeInfo.props;
        
        if (this.tradeInfo.type === ETradeType.SPOT) {
            const spotProps = props as ISpotTradeProps;
            if (this.isBuyer) {
                return { propertyId: spotProps.propIdForSale, amount: spotProps.amountForSale };
            } else {
                return { propertyId: spotProps.propIdDesired, amount: spotProps.amountDesired };
            }
        } else {
            // Futures - both sides commit collateral
            const futuresProps = props as IFuturesTradeProps;
            // Get margin from cache or compute
            const margin = this.cacheService.getCachedMargin(
                futuresProps.contract_id,
                futuresProps.amount,
                futuresProps.price
            );
            if (!margin) {
                throw new Error('Margin not pre-computed');
            }
            return { propertyId: margin.collateral, amount: margin.initMargin };
        }
    }

    private async buildAndSignFundingTx(propertyId: number, amount: number): Promise<{
        signedHex?: string;
        txid?: string;
        commitUtxo?: IUTXO;
        error?: string;
    }> {
        if (!this.multySigChannelData) {
            return { error: 'No multisig address' };
        }

        // Build payload
        const payload = ENCODER.encodeCommit({
            propertyId,
            amount,
            channelAddress: this.multySigChannelData.address
        });

        // Try to get pre-built tx from cache
        const prefundedResult = await this.balanceService.getOrBuildFundingTx(
            this.myInfo.keypair.address,
            this.multySigChannelData.address,
            propertyId,
            amount,
            payload
        );

        if (prefundedResult.error) {
            return { error: prefundedResult.error };
        }

        // Sign the funding tx
        const signRes = await this.txsService.signRawTxWithWallet(prefundedResult.data!.rawtx);
        if (signRes.error || !signRes.data?.signedHex) {
            return { error: signRes.error || 'Failed to sign funding tx' };
        }

        // Decode to get commit UTXO info
        const decodeRes = await this.client('decoderawtransaction', [signRes.data.signedHex]);
        if (decodeRes.error || !decodeRes.data?.vout) {
            return { error: 'Failed to decode funding tx' };
        }

        const vout = decodeRes.data.vout.find((o: any) =>
            o.scriptPubKey?.addresses?.[0] === this.multySigChannelData?.address
        );

        if (!vout) {
            return { error: 'No output to multisig found' };
        }

        const commitUtxo: IUTXO = {
            txid: '', // Will be set after broadcast
            vout: vout.n,
            amount: vout.value,
            scriptPubKey: this.multySigChannelData.scriptPubKey || '',
            redeemScript: this.multySigChannelData.redeemScript,
            confirmations: 0
        };

        return {
            signedHex: signRes.data.signedHex,
            commitUtxo
        };
    }

    private async buildTradePsbt(commitUtxo: IUTXO | undefined, useChannelBalance: boolean): Promise<{
        psbtHex?: string;
        error?: string;
    }> {
        // Get block height for expiry
        const blockHeightRes = await this.cacheService.getBlockHeight();
        if (blockHeightRes.error) {
            return { error: blockHeightRes.error };
        }
        const expiryBlock = blockHeightRes.data! + 10;

        // Build trade payload based on type
        const payload = this.buildTradePayload(expiryBlock);

        // Build PSBT
        const buildOptions = {
            buyerKeyPair: this.tradeInfo.buyer.keypair,
            sellerKeyPair: this.tradeInfo.seller.keypair,
            commitUTXOs: commitUtxo ? [commitUtxo] : [],
            payload,
            amount: 0
        };

        const psbtRes = await this.txsService.buildLTCITTx(buildOptions);
        if (psbtRes.error || !psbtRes.data?.psbtHex) {
            return { error: psbtRes.error || 'Failed to build PSBT' };
        }

        return { psbtHex: psbtRes.data.psbtHex };
    }

    private buildTradePayload(expiryBlock: number): string {
        const props = this.tradeInfo.props;
        
        // Determine column
        const column = this.cacheService.getCachedColumn(
            this.multySigChannelData!.address,
            this.myInfo.keypair.address,
            this.cpInfo.keypair.address
        ) || 'A';
        const isA = column === 'A' ? 1 : 0;
        const columnAIsMaker = isA === 1 
            ? (this.tradeInfo.buyerIsMaker ? 0 : 1)
            : (this.tradeInfo.buyerIsMaker ? 1 : 0);

        if (this.tradeInfo.type === ETradeType.SPOT) {
            const spotProps = props as ISpotTradeProps;
            
            if (spotProps.propIdDesired === 0 || spotProps.propIdForSale === 0) {
                // LTC trade
                return ENCODER.encodeTradeTokenForUTXO({
                    propertyId: spotProps.propIdForSale || spotProps.propIdDesired,
                    amount: spotProps.amountForSale || spotProps.amountDesired,
                    columnA: isA,
                    satsExpected: spotProps.propIdDesired === 0 ? spotProps.amountDesired : spotProps.amountForSale,
                    tokenOutput: 0,
                    payToAddress: 1
                });
            } else {
                // Token-to-token
                return ENCODER.encodeTradeTokensChannel({
                    propertyId1: spotProps.propIdForSale,
                    propertyId2: spotProps.propIdDesired,
                    amountOffered1: spotProps.amountForSale,
                    amountDesired2: spotProps.amountDesired,
                    expiryBlock,
                    columnAIsOfferer: isA,
                    columnAIsMaker
                });
            }
        } else {
            // Futures
            const futuresProps = props as IFuturesTradeProps;
            return ENCODER.encodeTradeContractChannel({
                contractId: futuresProps.contract_id,
                amount: futuresProps.amount,
                expiryBlock,
                price: futuresProps.price,
                columnAIsSeller: isA,
                insurance: false,
                columnAIsMaker
            });
        }
    }

    private async signPsbt(psbtHex: string): Promise<{ psbtHex?: string; error?: string }> {
        // Get WIF from cache
        const wifRes = await this.cacheService.getWif(this.myInfo.keypair.address);
        if (wifRes.error || !wifRes.data) {
            return { error: wifRes.error || 'Failed to get WIF' };
        }

        const signRes = await this.txsService.signPsbt({ wif: wifRes.data, psbtHex });
        if (signRes.error || !signRes.data?.psbtHex) {
            return { error: signRes.error || 'Failed to sign PSBT' };
        }

        return { psbtHex: signRes.data.psbtHex };
    }

    private async addInputToPsbt(psbtHex: string, utxo: IUTXO): Promise<{ psbtHex?: string; error?: string }> {
        // This would need implementation in txsService
        // For now, assume the PSBT builder handles this
        return { psbtHex };
    }

    private async finalizePsbt(psbtHex: string): Promise<{ finalHex?: string; error?: string }> {
        const finalizeRes = await this.txsService.finalizePsbt?.(psbtHex);
        if (!finalizeRes?.data?.finalHex) {
            return { error: 'Failed to finalize PSBT' };
        }
        return { finalHex: finalizeRes.data.finalHex };
    }

    private async checkRbf(txid: string): Promise<{ isRbf: boolean; error?: string }> {
        const txRes = await this.client('getrawtransaction', [txid, true]);
        if (txRes.error || !txRes.data?.vin) {
            return { isRbf: false, error: txRes.error };
        }
        
        const isRbf = txRes.data.vin.some((vin: any) => vin.sequence < 0xfffffffe);
        return { isRbf };
    }
}
