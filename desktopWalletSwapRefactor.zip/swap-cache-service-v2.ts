import { Injectable } from "@angular/core";
import { RpcService } from "./rpc.service";
import { AuthService } from "./auth.service";
import { TxsService } from "./txs.service";
import { IMSChannelData } from "src/app/utils/swapper/common";

/**
 * SwapCacheService - Optimized for 2-3 RT Streamlined Flow
 * 
 * CACHED DATA (eliminates RPCs entirely):
 * - WIFs: Pre-fetched on wallet load
 * - Block height: Polled every 10s in background
 * - Multisig addresses: Cached by pubkey pair (1 hour TTL)
 * - Column predictions: Deterministic, cached forever
 * - Margin calculations: Cached per contract/amount/price
 * 
 * STREAMING INTEGRATION:
 * - Works with BalanceService UTXO streaming
 * - Invalidates pre-funded txs on UTXO changes
 */

interface IMultisigCacheEntry {
    data: IMSChannelData;
    scriptPubKey: string;
    createdAt: number;
}

@Injectable({
    providedIn: 'root',
})
export class SwapCacheService {
    // WIF cache - keyed by address
    private wifCache: Map<string, string> = new Map();
    
    // Multisig cache - keyed by sorted pubkey pair
    private multisigCache: Map<string, IMultisigCacheEntry> = new Map();
    
    // Block height - single value with timestamp
    private blockHeight: number = 0;
    private blockHeightUpdatedAt: number = 0;
    
    // Column prediction cache
    private columnCache: Map<string, 'A' | 'B'> = new Map();

    // Margin cache - keyed by contract_id:amount:price
    private marginCache: Map<string, { initMargin: number; collateral: number }> = new Map();

    // TTLs
    private readonly BLOCK_HEIGHT_TTL_MS = 10_000;
    private readonly MULTISIG_TTL_MS = 3600_000;

    constructor(
        private rpcService: RpcService,
        private authService: AuthService,
        private txsService: TxsService
    ) {}

    // === INITIALIZATION ===

    async onInit(): Promise<void> {
        // Prefetch WIFs for all wallet addresses
        await this.prefetchWifs();
        
        // Start block height polling
        await this.refreshBlockHeight();
        setInterval(() => this.refreshBlockHeight(), this.BLOCK_HEIGHT_TTL_MS);
        
        // Refresh WIFs when addresses change
        this.authService.updateAddressesSubs$.subscribe(() => this.prefetchWifs());

        console.log('[SwapCache] Initialized:', this.getStats());
    }

    private async prefetchWifs(): Promise<void> {
        const addresses = this.authService.walletAddresses || [];
        
        for (const address of addresses) {
            if (!this.wifCache.has(address)) {
                try {
                    const res = await this.rpcService.rpc('dumpprivkey', [address]);
                    if (!res.error && res.data) {
                        this.wifCache.set(address, res.data);
                    }
                } catch (e) {
                    console.warn(`[SwapCache] Failed to prefetch WIF for ${address}`);
                }
            }
        }
    }

    private async refreshBlockHeight(): Promise<void> {
        try {
            const res = await this.rpcService.rpc('getblockcount');
            if (!res.error && res.data) {
                this.blockHeight = parseFloat(res.data);
                this.blockHeightUpdatedAt = Date.now();
            }
        } catch (e) {
            console.warn('[SwapCache] Failed to refresh block height');
        }
    }

    // === WIF ACCESS ===

    async getWif(address: string): Promise<{ data?: string; error?: string }> {
        // Check cache first
        const cached = this.wifCache.get(address);
        if (cached) {
            return { data: cached };
        }
        
        // Fallback to RPC
        const res = await this.rpcService.rpc('dumpprivkey', [address]);
        if (!res.error && res.data) {
            this.wifCache.set(address, res.data);
            return { data: res.data };
        }
        
        return { error: res.error || 'Failed to get WIF' };
    }

    // === BLOCK HEIGHT ===

    async getBlockHeight(): Promise<{ data?: number; error?: string }> {
        // Use cache if fresh
        if (Date.now() - this.blockHeightUpdatedAt < this.BLOCK_HEIGHT_TTL_MS) {
            return { data: this.blockHeight };
        }
        
        // Refresh
        await this.refreshBlockHeight();
        return this.blockHeight > 0 
            ? { data: this.blockHeight }
            : { error: 'Failed to get block height' };
    }

    // === MULTISIG MANAGEMENT ===

    private getMultisigKey(pubkeys: [string, string]): string {
        return [...pubkeys].sort().join(':');
    }

    async getOrCreateMultisig(pubkeys: [string, string]): Promise<{
        data?: IMSChannelData & { scriptPubKey: string };
        error?: string;
    }> {
        const key = this.getMultisigKey(pubkeys);
        const cached = this.multisigCache.get(key);
        
        // Check cache
        if (cached && (Date.now() - cached.createdAt) < this.MULTISIG_TTL_MS) {
            return { data: { ...cached.data, scriptPubKey: cached.scriptPubKey } };
        }
        
        // Create new multisig
        const amaRes = await this.rpcService.rpc('addmultisigaddress', [2, pubkeys]);
        if (amaRes.error || !amaRes.data) {
            return { error: amaRes.error || 'Failed to create multisig' };
        }
        
        const msData = amaRes.data as IMSChannelData;
        
        // Get scriptPubKey
        const validateRes = await this.rpcService.rpc('validateaddress', [msData.address]);
        if (validateRes.error || !validateRes.data?.scriptPubKey) {
            return { error: validateRes.error || 'Failed to validate multisig' };
        }
        
        const scriptPubKey = validateRes.data.scriptPubKey;
        
        // Cache
        this.multisigCache.set(key, {
            data: msData,
            scriptPubKey,
            createdAt: Date.now()
        });
        
        return { data: { ...msData, scriptPubKey } };
    }

    async verifyMultisig(pubkeys: [string, string], expectedRedeemScript: string): Promise<{
        valid: boolean;
        data?: IMSChannelData & { scriptPubKey: string };
        error?: string;
    }> {
        const result = await this.getOrCreateMultisig(pubkeys);
        if (result.error || !result.data) {
            return { valid: false, error: result.error };
        }
        
        if (result.data.redeemScript !== expectedRedeemScript) {
            return { valid: false, error: 'redeemScript mismatch' };
        }
        
        return { valid: true, data: result.data };
    }

    // === COLUMN PREDICTION ===

    getCachedColumn(msAddress: string, addr1: string, addr2: string): 'A' | 'B' | null {
        return this.columnCache.get(`${msAddress}:${addr1}:${addr2}`) || null;
    }

    cacheColumn(msAddress: string, addr1: string, addr2: string, column: 'A' | 'B'): void {
        this.columnCache.set(`${msAddress}:${addr1}:${addr2}`, column);
    }

    // === MARGIN CALCULATION ===

    getCachedMargin(contractId: number, amount: number, price: number): { initMargin: number; collateral: number } | null {
        return this.marginCache.get(`${contractId}:${amount}:${price}`) || null;
    }

    cacheMargin(contractId: number, amount: number, price: number, margin: { initMargin: number; collateral: number }): void {
        this.marginCache.set(`${contractId}:${amount}:${price}`, margin);
    }

    async getOrComputeMargin(contractId: number, amount: number, price: number): Promise<{ initMargin: number; collateral: number }> {
        const cached = this.getCachedMargin(contractId, amount, price);
        if (cached) return cached;
        
        const computed = await this.txsService.computeMargin(contractId, amount, price);
        this.cacheMargin(contractId, amount, price, computed);
        return computed;
    }

    // === CACHE MANAGEMENT ===

    clearAll(): void {
        this.wifCache.clear();
        this.multisigCache.clear();
        this.columnCache.clear();
        this.marginCache.clear();
    }

    clearCounterpartyCache(cpPubkey: string): void {
        for (const key of this.multisigCache.keys()) {
            if (key.includes(cpPubkey)) {
                this.multisigCache.delete(key);
            }
        }
    }

    getStats(): { wifs: number; multisigs: number; columns: number; margins: number; blockHeight: number } {
        return {
            wifs: this.wifCache.size,
            multisigs: this.multisigCache.size,
            columns: this.columnCache.size,
            margins: this.marginCache.size,
            blockHeight: this.blockHeight
        };
    }
}
